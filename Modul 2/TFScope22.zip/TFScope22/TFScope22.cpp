/*
 *  TFScope - Library untuk EScope versi 2022
 *
 * (c) Eko M. Budi, 2022
 * Released into the public domain.
 */
#include <Arduino.h>
#include "TFScope22.h"

AnalogButton::AnalogButton() {
    pinMode(bt_pin, INPUT);
}

/* construt AnalogButton with calibrated tresholds
*/
AnalogButton::AnalogButton(int tresholds[]) {
    for (int i=0; i<7; i++) {
        tbuttons[i] = tresholds[i];
    }
}

/* set pin for button
*/
void AnalogButton::setPin(int pin) {
    bt_pin= pin;
    pinMode(pin, INPUT);
}

/* convert analog value to bit value of all button
*/
byte AnalogButton::a2d(int a) {
    for (int i=0; i<7; i++) {
        if (a < tbuttons[i]) return dbuttons[i];
    }
    return dbuttons[7];
}

/* read analog value from ADC 
*/
int AnalogButton::aRead() {
    int sum = 0;
    // baca 5 kali, kalau ada jitter batalkan
    for (int i=0; i<5; i++) {
        int a = analogRead(bt_pin);   
        if ( a < (AD_MAX/3)) return 0;
        delay(1);
        sum += a;
    }
    return (sum/5); // rata-ratakan    
}

MultiLED::MultiLED() {
    for (int i=0; i<N_LED; i++) {
        pinMode(pins[i], OUTPUT);
    }
}

/* nyalakan LED
*/
void MultiLED::write(int idx, bool d) {
    if (idx >= N_LED) return;
    status[idx] = d;
    digitalWrite(pins[idx], d);
}

/* nyalakan semua LED sesuai status terakhir
*/
void MultiLED::write() {
    for (int i=0; i<N_LED; i++) {
        digitalWrite(pins[i], status[i]);
    }
}

// putar LED ke kiri
void MultiLED::rotateLeft() {
    bool temp=status[0];
    for(int i=0; i<N_LED-1; i++) {
        status[i] = status[i+1];
    }
    status[N_LED-1] = temp;
}

// putar LED ke kanan
void MultiLED::rotateRight() {
    bool temp=status[N_LED-1];
    for(int i=N_LED-1; i<0; i--) {
        status[i-1] = status[i];
    }
    status[0] = temp;
} 

