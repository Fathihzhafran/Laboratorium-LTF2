/*
 *  TFScope - Library untuk EScope versi 2022
 *
 * (c) Eko M. Budi, 2022
 * Released into the public domain.
 */
#ifndef TFScope2022_h
#define TFScope2022_h

// Standar pins for ESCOPE 2022
#define AO0 26
#define AO1 25

#define DO0 12
#define DO1 14
#define DO2 27
#define DO3 13

#define AI0 36
#define AI1 39

#define DI0 34
#define DI1 35
#define DI2 32
#define DI3 17

#define LED0 16
#define LED1 4
#define LED2 15

#define BT0 33

#define N_LED 3
#define N_BUTTON 3
#define N_DI 4
#define N_DO 4
#define N_AI 2
#define N_AO 2


#define DA_MAX 255
#define AD_MAX 4095


// OLED
#define OLED_WIDTH   128 
#define OLED_HEIGHT  32 
#define OLED_RESET   4
#define OLED_ADDR    0x3C

#define BUTTON0 0x01
#define BUTTON1 0x02
#define BUTTON2 0x04

class AnalogButton {
    const byte dbuttons[8] = {
        B000, B001, B010, B100, B011, B101, B110, B111
    };
    int tbuttons[7] = {
        1620,2420,2580,2740,2840,3070,3210
    };
    int bt_pin = BT0;

    public:
    /* construt AnalogButton with the default treshold (uncalibrated)
    */
    AnalogButton();

    /* construt AnalogButton with calibrated tresholds
    */
    AnalogButton(int tresholds[]);

    /* set pin
    */
    void setPin(int pin);

    /* convert analog value to bit value of all button
    */
    byte a2d(int a);

    /* convert analog value to bit value of a particular button
    */
    bool a2d(int a, int idx) {
        return ((a2d(a) >> idx) & 1);
    }

    /* read analog value from ADC 
    */
    int aRead();

    /* read bit value of all buttons
    */
    byte read() {
        return a2d(aRead());
    }

    /* read bit value of a particular button
    */
    bool read(int idx) {
        return a2d(aRead(), idx);
    }
};


class MultiLED {
    int pins[N_LED] = {LED0, LED1, LED2};
    bool status[N_LED] = {0,0,0};

    public:
    /* construt multiLED 
    */
    MultiLED();

    /* nyalakan LED
    */
    void write(int idx, bool d);

    /* membaca status terakhir LED
    */
    bool getStatus(int idx) {
        return status[idx];
    }

    /* nyalakan semua LED sesuai status terakhir
    */
    void write();

    // putar LED ke kiri
    void rotateLeft();

    // putar LED ke kanan
    void rotateRight();
};


#endif
